# DISCORD API

## Prerequisite
- I will help nobody !
- https://youtu.be/BfawQ0xZsF4

## Credit
💖 Create by MasterLua
