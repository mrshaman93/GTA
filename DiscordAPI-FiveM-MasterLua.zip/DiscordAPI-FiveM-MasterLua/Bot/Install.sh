npm i discord.js
npm i quake3-rcon